package com.qsp.springboot_employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootEmployeeApplication.class, args);
	}

}
