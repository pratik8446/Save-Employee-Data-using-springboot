package com.qsp.springboot_employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.qsp.springboot_employee.dao.EmployeeDao;
import com.qsp.springboot_employee.dto.Employee;

@RestController
public class emp_controller {
	
	@Autowired
	private EmployeeDao dao;
	
	@PostMapping("/save")
	public Employee saveEmp(@RequestBody Employee employee)
	{
		return dao.saveEmployee(employee);
	}
	
	@GetMapping("/fetch")
	public Employee getEmployee(@RequestParam int id)
	{
		return dao.getEmployee(id);
	}
	@GetMapping("/fetchAll")
	public List<Employee> getAllEmployees() {
		return dao.getAllEmployee();
		
	}
	@DeleteMapping("/delete/{id}")
	public Employee deletEmployee(@PathVariable int id) {
		return dao.deleteEmployee(id);
	}
	@PutMapping("/update")
	public Employee updateEmployee(@RequestParam int id,@RequestBody Employee employee) {
		return dao.updateEmployee(id,employee);
	}
	
	@PatchMapping("/updateSalary")
	public Employee updateSalary(@RequestParam int id,@RequestParam double salary) {
		return dao.updateSalary(id,salary);
		
	}
	@GetMapping("/fetchByEmail")
	public Employee getEmployeeByEmail(@RequestParam String email) {
		return dao.getEmployeeByEmail(email);
	}
	@GetMapping("/fetchByPhone/{phone}")
	public Employee getEmployeeByPhone(@PathVariable long phone) {
		return dao.getEmployeeByPhone(phone);
		
	}
	@GetMapping("/findBySalaryGreaterThan")
	public List<Employee> findEmployessBasedOnSalary(@RequestParam double salary) {
		return dao.findEmployessBasedOnSalary(salary);
		
	}
	
	

}
