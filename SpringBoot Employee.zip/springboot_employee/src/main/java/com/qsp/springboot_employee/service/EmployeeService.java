package com.qsp.springboot_employee.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.qsp.springboot_employee.dao.EmployeeDao;
import com.qsp.springboot_employee.dto.Employee;
import com.qsp.springboot_employee.util.ResponseStructure;

@Service
public class EmployeeService {
	@Autowired
	private EmployeeDao dao;
	
	ResponseStructure<Employee> responseStructure=new ResponseStructure<>();
	
	public ResponseStructure<Employee> saveEmployee(Employee employee) {
		if (employee.getSalary()>0 && employee.getSalary()<=10000) {
			employee.setGrade('D');
		}  else if (employee.getSalary()>10000 && employee.getSalary()<=20000) {
			employee.setGrade('C');
		} else if(employee.getSalary()>20000 && employee.getSalary()<=40000) {
				employee.setGrade('B');
			}
			else {
				employee.setGrade('A');
			}
		responseStructure.setMessage("saved successfully");
		responseStructure.setStatus(HttpStatus.CREATED.value());
		responseStructure.setData(dao.saveEmployee(employee));
		return responseStructure;
		
	}
}
