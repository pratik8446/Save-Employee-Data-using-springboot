package com.qsp.springboot_employee.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.qsp.springboot_employee.dto.Employee;
import com.qsp.springboot_employee.repo.EmployeeRepo;

@Repository
public class EmployeeDao {

	@Autowired
	private EmployeeRepo repo;
	
	public Employee saveEmployee(Employee employee)
	{
		return repo.save(employee);
	}

	public Employee getEmployee(int id) {
		
		return repo.findById(id).get();
	}
	
	public List<Employee> getAllEmployee() {

		return repo.findAll();
	}

	public Employee deleteEmployee(int id) {
		Optional<Employee> optional = repo.findById(id);
		if (optional.isEmpty()) {
			return null;
		}
		repo.deleteById(id);
		return optional.get();
	}

	public Employee updateEmployee(int id, Employee employee) {
		//Employee dbEmployee = repo.findById(id).get();
		Optional<Employee> dbEmployee=repo.findById(id);
		if (dbEmployee.isPresent()) {     //for NoSuchElementException
			employee.setId(id);
			return repo.save(employee);
		}
		return null;
	}

	public Employee updateSalary(int id, double salary) {
		Optional<Employee> optional=repo.findById(id);
		if(optional.isPresent()) {
			Employee employee=optional.get();
			employee.setSalary(salary);
			return repo.save(employee);
		}
		return null;
	}

	public Employee getEmployeeByEmail(String email) {
		
		return repo.findByEmail(email);
	}

	public Employee getEmployeeByPhone(long phone) {
		return repo.employeeByPhone(phone);
	}

	public List<Employee> findEmployessBasedOnSalary(double salary) {
		
		return repo.findBySalaryGreaterThan(salary);
	}
	

}
