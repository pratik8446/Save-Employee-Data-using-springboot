package com.qsp.springboot_employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
